<?php
    $link = mysqli_connect('localhost','user','password','dbname');
    if (isset($_GET["action"])) { 
        $action = $_GET['action'];
    }else{ $action=null; }
    
    if (isset($_GET["id_statement"])) { 
        $id_statement = $_GET['id_statement'];
    }else{ $id_statement=null; }
    
    if (isset($_GET["id_subject"])) { 
        $id_subject = $_GET['id_subject'];
    }else{ $id_subject=null; }
    
    if (isset($_GET["id_user"])) { 
        $id_user = $_GET['id_user'];
    }else{ $id_user=null; }
    
    if (isset($_GET["status"])) { 
        $status = $_GET['status'];
    }else{ $status=null; }
    
    if (isset($_GET["title"])) { 
        $title = $_GET['title'];
    }else{ $title=null; }
    
    if (isset($_GET["grid"])) { 
        $grid = $_GET['grid'];
    }else{ $grid=null; }
    
    if (isset($_GET["id_mark"])) { 
        $id_mark = $_GET['id_mark'];
    }else{ $id_mark=null; }
    
    
    
    if($action=="remove_mark"){
        if($id_mark!=null){
            if(mysqli_query($link,"DELETE FROM mark WHERE id_mark=". $id_mark ."")){
                
                $resp_message[] = array("response" => "success");

            }else{
                $resp_message[] = array("response" => "fail");
            }
            
            echo json_encode($resp_message);
        }
    }
    
    
    
    
    if($action=="select_all"){
        $res=mysqli_query($link, "SELECT * FROM statement");
        while($e=mysqli_fetch_assoc($res))
            $output[]=$e;
            print(json_encode($output));
            if($res) {
					mysqli_free_result($res);
				}
        }
        
    
    if($action=="select"){
        if($id_statement!=null){
            $res=mysqli_query($link, "SELECT * FROM statement WHERE id_statement=".$id_statement);
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
        
        
    if($action=="select_subject_from_st_for_sm"){
        if($id_mark!=null){
            $res=mysqli_query($link, "SELECT * FROM subject AS a INNER JOIN statement AS b ON (a.id_subject=b.id_subject) INNER JOIN mark AS c ON (b.id_statement=c.id_statement) WHERE c.id_mark=".$id_mark);
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
        
    
    if($action=="select_subject_from_st"){
        if($id_statement!=null){
            $res=mysqli_query($link, "SELECT * FROM subject AS a INNER JOIN statement AS b ON (a.id_subject=b.id_subject) WHERE b.id_statement=".$id_statement);
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
    
    
    if($action=="select_marks_for_stud"){
        if($id_user!=null){
            $res=mysqli_query($link, "SELECT * FROM mark WHERE id_user=".$id_user);
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
    
    
    if($action=="select_badmarks_for_stud"){
        if($id_user!=null){
            $res=mysqli_query($link, "SELECT * FROM mark WHERE id_user=".$id_user." AND mark<3");
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
    
    
    if($action=="select_prepstatements"){
        if($id_user!=null){
            $res=mysqli_query($link, "SELECT * FROM statement WHERE id_user=".$id_user." AND status='opened'");
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
        
        if($action=="select_prep_rc_statements"){
        if($id_user!=null){
            $res=mysqli_query($link, "SELECT * FROM statement WHERE id_user=".$id_user." AND (status='ready' or status='closed')");
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
    
    
    if($action=="select_ready"){
            $res=mysqli_query($link, "SELECT * FROM statement WHERE status='ready'");
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
    
    if($action=="create_new_statement"){
        if($id_subject!=null & $id_user!=null & $title!=null & $grid!=null){
            $title = str_replace('_', ' ', $title);
            if(mysqli_query($link,"INSERT INTO statement(id_statement,id_subject,id_user,status,title,grid) VALUES(null,".$id_subject.",".$id_user.",'opened','".$title."',".$grid.")")){
                
                $resp_message[] = array("response" => "success");

            }else{
                $resp_message[] = array("response" => "fail");
            }
            
            echo json_encode($resp_message);
        }
    }
    
    if($action=="change_statement_status"){
        if($status!=null & $id_statement!=null){
            if(mysqli_query($link,"UPDATE statement SET statement.status='".$status."' WHERE id_statement='".$id_statement."'")){
                
                $resp_message[] = array("response" => "success");

            }else{
                $resp_message[] = array("response" => "fail");
            }
            
            echo json_encode($resp_message);
        }
    }
     mysqli_close($link);
?>
<?php
    $link = mysqli_connect('localhost','user','password','dbname');
    if (isset($_GET["action"])) { 
        $action = $_GET['action'];
    }   
    if (isset($_GET["id_subject"])) { 
        $id_subject = $_GET['id_subject'];
    }else{$id_subject=null;}

    if($action == "select"){
        if($id_subject != null){
       
        $res=mysqli_query($link, "SELECT * FROM subject WHERE id_subject=".$id_subject);
        while($e=mysqli_fetch_assoc($res))
            $output[]=$e;
            print(json_encode($output));
       
        if($res) {
					mysqli_free_result($res);
				}
    } }
    
    if($action == "select_all"){
        
        $res=mysqli_query($link, "SELECT * FROM subject");
        while($e=mysqli_fetch_assoc($res))
            $output[]=$e;
            print(json_encode($output));
        
        if($res) {
					mysqli_free_result($res);
				}
    }
    
    if($action == "insert"){
        
    }
    mysqli_close($link);
?>
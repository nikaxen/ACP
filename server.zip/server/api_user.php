<?php
    $link = mysqli_connect('localhost','user','password','dbname');
    if (isset($_GET["action"])) { 
        $action = $_GET['action'];
    }else{ $action=null; }
    
    if (isset($_GET["id_user"])) { 
        $id_user = $_GET['id_user'];
    }else{ $id_user=null; }
    if (isset($_GET["id_st_gr"])) { 
        $id_st_gr = $_GET['id_st_gr'];
    }else{ $id_st_gr=null; }
    
    if (isset($_GET["id_statement"])) { 
        $id_statement = $_GET['id_statement'];
    }else{ $id_statement=null; }
    
     if (isset($_GET["mark"])) { 
        $mark = $_GET['mark'];
    }else{ $mark=null; }
    
    if (isset($_GET["fio"])) { 
        $fio = $_GET['fio'];
    }else{ $fio=null; }
    
    if (isset($_GET["rolename"])) { 
        $rolename = $_GET['rolename'];
    }else{ $rolename=null; }
    
    if (isset($_GET["password"])) { 
        $password = $_GET['password'];
    }else{ $password=null; }
    
    if (isset($_GET["email"])) { 
        $email = $_GET['email'];
    }else{ $email=null; }
    
    if (isset($_GET["grid"])) { 
        $grid = $_GET['grid'];
    }else{ $grid=null; }
    
    if($action=="select_all"){
        $res=mysqli_query($link, "SELECT * FROM user");
        while($e=mysqli_fetch_assoc($res))
            $output[]=$e;
            print(json_encode($output));
            if($res) {
					mysqli_free_result($res);
				}
        }
        
    
    if($action=="select"){
        if($id_user!=null){
            $res=mysqli_query($link, "SELECT * FROM user WHERE id_user=".$id_user);
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
    
    
    
    if($action=="select_marks_in_st"){
        if($id_statement!=null){
            $res=mysqli_query($link, "SELECT * FROM mark WHERE id_statement=".$id_statement);
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
    
    if($action=="select_studs_in_studgroup"){
        if($id_statement!=null){
            $res=mysqli_query($link, "SELECT a.id_user, a.fio FROM `user` AS a INNER JOIN `studingroup` AS b ON (a.id_user = b.studid) INNER JOIN `statement` AS c ON (c.grid = b.groupid) WHERE c.id_statement=".$id_statement);
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
    
    
    
    if($action=="select_user_studgroup"){
        if($id_user!=null){
            $res=mysqli_query($link, "SELECT * FROM studgroup AS a INNER JOIN studingroup AS b ON (a.sgid = b.groupid) WHERE b.studid=".$id_user);
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
    
    
    if($action=="select_studgroup"){
        if($grid!=null){
            $res=mysqli_query($link, "SELECT * FROM studgroup WHERE sgid=".$grid);
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            }
        }
    
    
    
    if($action=="change_userrole"){
        if($rolename!=null & $id_user!=null){
            if(mysqli_query($link,"UPDATE user SET user.rolename='".$rolename."' WHERE id_user='".$id_user."'")){
                
                $resp_message[] = array("response" => "success", "rolename"=>$rolename);

            }else{
                $resp_message[] = array("response" => "fail");
            }
            
            echo json_encode($resp_message);
        }
    }
    
    if($action=="select_preplist"){
        
            $res=mysqli_query($link, "SELECT * FROM user WHERE rolename ='prep'");
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            
        }
    
    
    if($action=="select_studlist"){
        
            $res=mysqli_query($link, "SELECT * FROM user WHERE rolename ='stud'");
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            
        }
    
        if($action=="select_studgrouplist"){
        
            $res=mysqli_query($link, "SELECT * FROM studgroup");
            while($e=mysqli_fetch_assoc($res))
                $output[]=$e;
                print(json_encode($output));
                if($res) {
					mysqli_free_result($res);
				}
            
        }
        
        
    if($action=="add_user_studgroup"){
        if($id_user!=null && $id_st_gr!=null){
            
            
            if(mysqli_query($link,"INSERT INTO studingroup(con_id,studid,groupid) VALUES(null, ".$id_user.",".$id_st_gr.")")){
                
                $resp_message[] = array("response" => "success", "rolename"=>$rolename);

            }else{
                $resp_message[] = array("response" => "fail");
            }
            
                    print(json_encode($output));
                
            }
        }
    
    if($action=="auth"){
        if($email!=null && $password!=null){
            $res=mysqli_query($link, "SELECT * FROM user WHERE email='".$email."' AND password='".$password."'");
            
            if($res) {
                while($e=mysqli_fetch_assoc($res))
                    
                    $output[]=$e;
                    
                    if(empty($output)){
                        $output[]=array('response'=> "fail");
                    }
                    
                    print(json_encode($output));
                
					mysqli_free_result($res);
				}
            }
        }
    
    if($action=="reg"){
        if($fio!=null & $email!=null & $password!=null){
            $fio = str_replace('_', ' ', $fio);

            if(mysqli_query($link,"INSERT INTO user(id_user,fio,rolename,password,email) VALUES (null,'".$fio."','neizv','".$password."','".$email."')")){
                $resp_message="success";
            }else{
                $resp_message="fail";
            }
            
            echo json_encode(array('response'=> $resp_message));
        }
    }
    
    if($action=="add_mark"){
        if($id_statement!=null & $id_user!=null & $mark!=null){
            if(mysqli_query($link,"INSERT INTO mark(id_mark,id_statement,id_user,mark) VALUES (null,".$id_statement.",".$id_user.",".$mark.")")){
                $resp_message="success";
            }else{
                $resp_message="fail";
            }
            
            echo json_encode(array('response'=> $resp_message));
        }
    }
    
    //close db connection
    
        mysqli_close($link);
?>